<!-- generated-on="<?php echo $date; ?>" -->
<!-- generator="XML Sitemap & Google News for WordPress" -->
<!-- generator-url="https://status301.net/wordpress-plugins/xml-sitemap-feed/" -->
<!-- generator-version="<?php echo XMLSF_VERSION; ?>" -->
