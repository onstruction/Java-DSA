<!-- Queries executed: <?php echo $num; if ( $mem ) { ?> | Peak memory usage: <?php echo $mem; } ?> | Memory limit: <?php echo $limit; ?> -->
